import React from 'react'

const DetailProduct = () => {
  return (
    <div>
      Detail Project
    </div>
  )
}

export default DetailProduct
